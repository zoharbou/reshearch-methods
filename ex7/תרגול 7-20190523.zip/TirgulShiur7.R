##################ANOVA repeated measures##################
getwd()
setwd("")
####Example from class

##Organize the data:
data_reading=data.frame(Subject=1:10,
                     Nouns=c(600,530,580,620,650,650,500,610,590,600),
                     Verbs=c(800,550,700,650,650,620,450,850,650,630),
                     Adjectives=c(750,520,680,610,600,650,480,700,630,630))

str(data_reading)
data_reading$Subject=factor(data_reading$Subject)
str(data_reading)

#alternative:
library("readxl")
data_reading_table <- read_excel("Data_reading.xlsx")
data_reading=data.frame(data_reading_table)
data_reading$Subject=factor(data_reading$Subject)

#This is called the wide format: subject's repeated responses 
#will be in a single row, and each response is in a separate column.
data_reading

#change into long format, to do ANOVA repeated measures
library(tidyr)
data_long <- gather(data= data_reading, 
                    key=wordType, 
                    value=RT, 
                    ...=Nouns:Adjectives, 
                    factor_key=TRUE) #to store as a factor
#in long format- each row is one point per subject.
#Therefore, each subject will have data in multiple rows.
data_long


#order according to Subject, more frequent in data analyzing:
data_long2=data_long[order(data_long$Subject),]
data_long2

#and from long to wide format:
library(tidyr)
data_wide <- spread(data= data_long, key= wordType, value= RT)
data_wide

#Now, for the purpose of the example,
#Let's assume all assumptions for the Anova test are true.

#ANOVA repeated measures
aov_repeated=aov(RT ~ wordType + Error(Subject/wordType), data = data_long2)
summary(aov_repeated)

#graph 1
library(Rmisc)
#Summarizes data, handling within-subjects variables 
#by removing inter-subject variability
dfw = summarySEwithin(data=data_long2, 
                      measurevar="RT", 
                      withinvars="wordType",
                      idvar="Subject", 
                      conf.interval=.95)
#you can compare it to the output of summarySE
#for further reading: http://www.cookbook-r.com/Graphs/Plotting_means_and_error_bars_(ggplot2)/#Helper%20functions

library(ggplot2)
ggplot(dfw, aes(x=wordType, y=RT, group=1)) +
  geom_line() +
  geom_errorbar(width=.1, aes(ymin=RT-ci, ymax=RT+ci)) +
  geom_point(shape=21, size=3, fill="black")+
  ggtitle("Within subject design \n reaction time with CI to diffrent types of words")+
  xlab("Condition: Type of word")+
  ylab("Reaction time ms")+
  ylim(c(0,700))+
  theme(plot.title = element_text(hjust = 0.5))

#graph 2
ggplot(data_long) +
  geom_path(aes(x =wordType , y = RT, group = interaction(wordType, Subject), color = Subject)) +
  geom_point(aes(x = wordType, y = RT, color = Subject), size = 3)+
  scale_shape_manual(values=seq(0,9))+
  ylim(c(0, 900))+
  ggtitle("Reaction time of subjects to different types of words \n with marked means for each condition")+
  xlab("Condition: Type of word")+
  ylab("Reaction time ms")+
  theme(plot.title = element_text(hjust = 0.5))+
  stat_summary(data=data_long, aes(x =wordType , y = RT, group=1),fun.y = mean, color = "black", geom = "line")+
  stat_summary(fun.y = mean, color = "black", geom ="point", aes(x =wordType , y = RT, group=1), size = 0.9,
               show.legend = FALSE,data=data_long )

  
#check the ANOVA "manually"
k=as.numeric(length(unique(data_long$wordType)))
n=as.numeric(length(unique(data_long$Subject)))
library(plyr)
means_cond=ddply(data_long, "wordType", summarise,
                 mean=mean(RT))
means_subj=ddply(data_long, "Subject", summarise,
                 mean=mean(RT))

means_cond_sorted=rep(means_cond$mean, each=10)

SSB=n*sum((means_cond$mean-mean(data_long$RT))^2)
SSint=sum((data_long$RT-means_subj$mean-means_cond_sorted
           +mean(data_long$RT))^2)

SSS=k*sum((means_subj$mean-mean(data_long$RT))^2)
dfs=length(data_reading$Subject) -1
MSS=SSS/dfs

df1=k-1
df2=(k-1)*(n-1)
MSB= SSB/df1
MSint=SSint/df2
MSB/MSint
1-pf(MSB/MSint, df1, df2)

#Example for another dataset and another function. 
#Function same as aov, rounds less, more output.
#The chopsticks' research:
Data_chop=read.csv("Data_chop.csv", header=TRUE)
Data_chop$LengthChop=factor(Data_chop$LengthChop)
Data_chop$Subject=factor(Data_chop$Subject)
str(Data_chop)

#check normality for each condition:
for (samples in seq(from=1, by=31, to=nrow(Data_chop))){
  check=shapiro.test(Data_chop[samples:(samples+30),]$FoodPincingAvg)
  print(check$p.value>0.05)
}

library(ez)
#function ezANOVA
anova_wi=ezANOVA(data= Data_chop,
                 wid=Subject, #identifier/index. 
                 #in this case: subject.
                 #could be a city, a mouse etc.
                 within = LengthChop,
                 dv=FoodPincingAvg,
                 type=2, #default 
                 return_aov = TRUE)
anova_wi
#estimated effects may be unbalnaced: in other words, be carfull for unbalanced design.
#Balanced design is: An experimental design where all cells 
#have the same number of observations

#ges- generalized eta-squared (not partial!)
#you can calculate partial eta-squared from the output 

#sphericity corrections:
#violation causes the test to become too liberal 
#(increase in the Type I error rate).

#Greenhouse-Geisser & Huynh-Feldt epsilon values 
#correct the degrees of freedom of the F-distribution. (does not change F statistics and SS'im)
#This table also gives the corresponding corrected p-values.

#Further reading for those who are interested 
#in which correction to use, why and when:

#The Greenhouse-Geisser correction tends to underestimate 
#epsilon when epsilon is close to 1 (i.e., it is a conservative correction), 
#whilst the Huynd-Feldt correction tends to overestimate 
#epsilon (i.e., it is a more liberal correction).

#The Huynh-Feldt epsilon is an alternative 
#that is not as conservative as the Greenhouse-Geisser epsilon;
#however, it may have a value greater than 1. 
#When its calculated value is greater than 1, 
#the Huynh-Feldt epsilon used is 1.000.

#Generally, the recommendation is to use the Greenhouse-Geisser correction, 
#especially if estimated epsilon is less than 0.75. 
#Some statisticians recommend using the Huynd-Feldt correction 
#if estimated epsilon is greater than 0.75. 
#In practice, both corrections produce very similar corrections, 
#so if estimated epsilon is greater than 0.75, 
#you can equally justify using either.
#The Greenhouse-Geisser epsilon can be conservative, especially for small sample sizes.
